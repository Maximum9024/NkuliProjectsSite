function myNavFunction(){
    var i = document.getElementById("navId");
     if(i.className==="myNavigation"){
         i.className +="responsive"; 
     }  else {
         i.className="myNavigation";
     }
}